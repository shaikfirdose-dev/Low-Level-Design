package Models;

public class Scorpio implements ICar{
}
