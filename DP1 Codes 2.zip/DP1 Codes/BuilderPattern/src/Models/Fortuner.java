package Models;

public class Fortuner implements ICar{
}
