package Models;

public interface ICar {
}
