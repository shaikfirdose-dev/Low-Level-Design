package Models;

public class DefenderEngine implements IEngine{
}
