package Models;

public class ScorpioEngine implements IEngine{
}
