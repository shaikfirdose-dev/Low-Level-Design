package Models;

public interface IBodyShell {
}
