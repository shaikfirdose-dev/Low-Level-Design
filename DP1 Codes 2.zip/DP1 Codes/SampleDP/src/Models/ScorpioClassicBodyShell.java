package Models;

public class ScorpioClassicBodyShell implements IBodyShell{
}
