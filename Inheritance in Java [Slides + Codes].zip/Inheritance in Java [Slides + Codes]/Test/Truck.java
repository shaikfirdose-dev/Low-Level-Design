package Test;

import Transport.Vehicle;

public class Truck extends Vehicle {
    Truck(){
        super();
//        this.name = "123";
    }
}
