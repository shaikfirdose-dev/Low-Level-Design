package Test;
import Transport.*;

public class TestMain {
    public static void main(String[] args) {
        Vehicle v = new Vehicle();
//        System.out.println(v.name);
    }
}
