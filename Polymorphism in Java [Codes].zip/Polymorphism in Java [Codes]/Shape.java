package Polymorphism;

public class Shape {
    public void draw(){
        System.out.println("Generic shape drawing...");
    }
}
