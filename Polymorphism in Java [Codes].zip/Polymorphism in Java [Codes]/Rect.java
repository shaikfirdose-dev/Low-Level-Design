package Polymorphism;

public class Rect extends Shape {
    public void draw(){
        System.out.println("Rect is drawing...");
    }
}
