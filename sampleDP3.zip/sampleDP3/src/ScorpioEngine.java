public class ScorpioEngine {
    public ScorpioEngine() {}

    public ScorpioEngine(ScorpioEngine scorpioEngine) {
        //copy logic here
    }

}
