public class ScorpioClassicEngine extends ScorpioEngine{
}
