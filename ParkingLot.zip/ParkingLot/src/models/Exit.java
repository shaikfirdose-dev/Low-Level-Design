package models;

public  class Exit {
    private int id;
    public  void validateTicket(ParkingTicket ticket) {
        //add ypur own impklemnetaion here

    }

}
