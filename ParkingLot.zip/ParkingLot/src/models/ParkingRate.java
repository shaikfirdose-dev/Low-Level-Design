package models;

public class ParkingRate {
    private double hours;
    private double rate;


    public double calculateAmount() {
        //addd your impl here
        return 0;
    }

}
