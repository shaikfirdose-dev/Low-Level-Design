package models;

import Interface.Vehicle;

public class Car extends Vehicle {
    @Override
    public void getTicket() {
        //add your own implementation
    }
}
