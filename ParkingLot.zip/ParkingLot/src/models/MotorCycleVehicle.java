package models;

import Interface.Vehicle;

public class MotorCycleVehicle extends Vehicle {
    @Override
    public void getTicket() {
        //add your own implementation
    }
}
