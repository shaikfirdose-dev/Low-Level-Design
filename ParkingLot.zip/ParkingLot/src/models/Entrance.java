package models;

import Interface.Vehicle;

public  class Entrance {
    private int id;

    public ParkingTicket getTicket(Vehicle vehicle) {
        //add ypur own implememtation here
        return null;
    }

}
