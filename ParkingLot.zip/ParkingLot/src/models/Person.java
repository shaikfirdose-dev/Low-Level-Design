package models;

public class Person {
    private String name;
    private String Address;
    private String email;
    private String phone;
}
