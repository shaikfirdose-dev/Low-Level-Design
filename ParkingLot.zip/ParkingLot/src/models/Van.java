package models;

import Interface.Vehicle;

public class Van extends Vehicle {
    @Override
    public void getTicket() {
        //add your own implementation
    }
}
