package models;

import Interface.Vehicle;

public class Truck extends Vehicle {
    @Override
    public void getTicket() {
        //add your own implementation
    }
}
