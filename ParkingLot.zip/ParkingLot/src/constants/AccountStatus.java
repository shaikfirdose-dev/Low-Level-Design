package constants;

public enum AccountStatus {
    ACTIVE, CLOSED, BLACKLISTED, NONE
}
