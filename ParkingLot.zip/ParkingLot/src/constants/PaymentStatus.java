package constants;

public enum PaymentStatus {
    COMPLETED, FAILED, PENDING, UNPAID, REFUNDED
}
