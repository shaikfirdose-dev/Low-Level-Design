package Interface;

public abstract class Vehicle {
    private int licenseNo;

    public abstract void getTicket();
}
