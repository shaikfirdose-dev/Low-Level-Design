package Models;

public class ScorpioBodyShell implements IBodyShell{
}
