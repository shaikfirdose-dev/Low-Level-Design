package Models;

public class ScorpioNEngine implements IEngine {
}
