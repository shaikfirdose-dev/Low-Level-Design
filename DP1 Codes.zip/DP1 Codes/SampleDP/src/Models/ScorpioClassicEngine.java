package Models;

public class ScorpioClassicEngine implements IEngine{
}
