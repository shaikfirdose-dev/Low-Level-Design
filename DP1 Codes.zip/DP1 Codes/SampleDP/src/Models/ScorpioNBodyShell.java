package Models;

public class ScorpioNBodyShell implements IBodyShell{
}
