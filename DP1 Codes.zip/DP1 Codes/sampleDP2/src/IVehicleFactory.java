import Models.IEngine;

public interface IVehicleFactory {

    public IEngine createEngine();
}
