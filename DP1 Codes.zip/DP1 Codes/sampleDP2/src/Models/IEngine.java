package Models;

public interface IEngine {
}
